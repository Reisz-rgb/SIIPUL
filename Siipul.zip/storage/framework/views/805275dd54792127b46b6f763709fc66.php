<footer class="mt-auto bg-primary-700 text-white">
    <div class="max-w-7xl mx-auto px-6 py-4">
        <p class="text-center text-xs text-white/80">SIIPUL © 2024 | Disdikbudpora Kab Semarang</p>
    </div>
</footer>
<?php /**PATH D:\SIIPUL\resources\views/user/partials/footer.blade.php ENDPATH**/ ?>