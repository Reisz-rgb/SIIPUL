<?php ($u = $user ?? auth()->user()); ?>

<header class="bg-primary-700 text-white shadow">
    <div class="w-full px-6 lg:px-10 h-16 flex items-center justify-between">
        <div class="max-w-7xl mx-auto w-full flex items-center justify-between">
            <div class="text-sm font-extrabold tracking-tight text-white/90">
                <?php echo $__env->yieldContent('nav_title', 'Dashboard'); ?>
            </div>

        
            <details class="relative">
            <summary id="userMenuBtn" class="list-none group inline-flex items-center gap-3 rounded-full bg-white/95 hover:bg-white px-3 py-1.5 shadow-soft border border-white/40 transition select-none cursor-pointer">
                <div class="text-right">
                    <div class="text-sm font-bold text-slate-900 leading-tight line-clamp-1"><?php echo e($u->name ?? '-'); ?></div>
                    <div class="text-xs text-slate-500 leading-tight line-clamp-1"><?php echo e($u->jabatan ?? 'Pegawai'); ?></div>
                </div>
                <span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-primary-700 text-white text-xs font-extrabold">
                    <?php echo e(strtoupper(substr($u->name ?? 'US', 0, 2))); ?>

                </span>
                <i class="fa-solid fa-chevron-down text-slate-500 text-[10px] pr-1"></i>
            </summary>

            
            <div class="dropdown-menu absolute right-0 mt-3 w-80 overflow-hidden rounded-2xl bg-white border border-slate-200 shadow-soft">
                <div class="p-5 border-b border-dashed border-slate-200 flex items-center gap-4">
                    <div class="h-12 w-12 rounded-full bg-primary-700 text-white flex items-center justify-center font-extrabold">
                        <?php echo e(strtoupper(substr($u->name ?? 'US', 0, 2))); ?>

                    </div>
                    <div class="min-w-0">
                        <div class="font-bold text-slate-900 truncate"><?php echo e($u->name ?? '-'); ?></div>
                        <div class="text-sm text-slate-500 truncate"><?php echo e($u->jabatan ?? 'Pegawai'); ?></div>
                    </div>
                </div>

                <div class="p-5 border-b border-dashed border-slate-200">
                    <div class="text-[11px] font-extrabold text-slate-400 tracking-wider uppercase">NIP</div>
                    <div class="mt-1 text-sm font-semibold text-slate-800"><?php echo e($u->nip ?? '-'); ?></div>
                    <div class="mt-4 text-[11px] font-extrabold text-slate-400 tracking-wider uppercase">Unit</div>
                    <div class="mt-1 text-sm font-semibold text-slate-800"><?php echo e($u->bidang_unit ?? '-'); ?></div>
                </div>

                <div class="p-2">
                    <a href="<?php echo e(route('user.profil')); ?>" class="flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                        <i class="fa-regular fa-user w-5 text-slate-400"></i>
                        Profil Saya
                    </a>
                    <a href="<?php echo e(route('user.riwayat')); ?>" class="flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                        <i class="fa-regular fa-file-lines w-5 text-slate-400"></i>
                        Riwayat Cuti
                    </a>
                    <a href="<?php echo e(route('user.password.change')); ?>" class="flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                        <i class="fa-solid fa-key w-5 text-slate-400"></i>
                        Ubah Password
                    </a>

                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="mt-2">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-full flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-danger-600 hover:bg-danger-50">
                            <i class="fa-solid fa-arrow-right-from-bracket w-5"></i>
                            Keluar
                        </button>
                    </form>
                </div>
            </div>
            </details>
        </div>
    </div>
</header>
<?php /**PATH D:\SIIPUL\resources\views/user/partials/topbar.blade.php ENDPATH**/ ?>