<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SIIPUL - Dashboard User</title>

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    * { font-family: 'Plus Jakarta Sans', sans-serif; }

    :root{
      --maroon: #9E2A2B;
      --maroon-dark: #781F1F;
      --bg: #F1F5F9;
      --card: #FFFFFF;
      --border: #E2E8F0;
      --text: #334155;
      --shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.1);
      --shadow-sm: 0 4px 6px -1px rgba(0,0,0,0.02);
    }

    body{ background: var(--bg); color: var(--text); }

    ::-webkit-scrollbar{ width: 6px; height: 6px; }
    ::-webkit-scrollbar-track{ background: transparent; }
    ::-webkit-scrollbar-thumb{ background: #CBD5E1; border-radius: 10px; }
    ::-webkit-scrollbar-thumb:hover{ background: #94A3B8; }

    .shadow-soft{ box-shadow: var(--shadow); }

    .active-menu{
      background: linear-gradient(90deg, var(--maroon) 0%, var(--maroon-dark) 100%);
      color: white !important;
      box-shadow: 0 4px 12px rgba(158, 42, 43, 0.3);
      border: none;
    }
    
    .menu-btn{ transition: all 0.2s ease; }
    .menu-btn:hover:not(.active-menu){ background: #FEF2F2; color: var(--maroon); }

    .card-hover{ transition: transform 0.2s; }
    .card-hover:hover{ transform: translateY(-3px); }

    .glass-profile {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .btn-primary{
      background: var(--maroon);
      transition: transform .15s ease, box-shadow .15s ease, background .15s ease;
    }
    .btn-primary:hover{
      background: var(--maroon-dark);
      transform: translateY(-1px);
      box-shadow: 0 10px 18px rgba(139, 21, 56, 0.18);
    }
  </style>
</head>

<body class="flex h-screen overflow-hidden">

  <div id="overlay" class="hidden fixed inset-0 bg-black/50 z-40 md:hidden" onclick="closeSidebar()"></div>

  <aside id="sidebar" class="w-[280px] bg-white border-r border-[var(--border)] flex-shrink-0 fixed md:static inset-y-0 left-0 z-50 -translate-x-full md:translate-x-0 transition-transform duration-300 flex flex-col">
    
    <div class="p-6 border-b border-dashed border-[var(--border)] mb-2">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 flex items-center justify-center bg-slate-50 rounded-xl p-1">
          <img src="<?php echo e(asset('logokabupatensemarang.png')); ?>" alt="Logo Kab Semarang" class="w-full h-full object-contain">
        </div>
        <div class="leading-tight">
          <div class="text-xl font-extrabold tracking-tight text-[var(--maroon)]">SIIPUL</div>
          <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Kab. Semarang</div>
        </div>
      </div>
    </div>

    <nav class="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
      <p class="text-[11px] font-bold text-slate-400 tracking-wider px-4 mb-3 mt-2 uppercase">Main Menu</p>

      <a href="<?php echo e(route('user.dashboard')); ?>" class="menu-btn active-menu w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium">
        <span class="menu-icon w-6 text-center text-lg"><i class="bi bi-grid-fill"></i></span>
        <span>Dashboard</span>
      </a>

      <a href="<?php echo e(route('user.riwayat')); ?>" class="menu-btn w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-500 hover:text-[var(--maroon)]">
        <span class="menu-icon w-6 text-center text-lg"><i class="bi bi-file-earmark-text"></i></span>
        <span>Riwayat Cuti</span>
      </a>
      
      <a href="<?php echo e(route('user.profil')); ?>" class="menu-btn w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-500 hover:text-[var(--maroon)]">
        <span class="menu-icon w-6 text-center text-lg"><i class="bi bi-person-gear"></i></span>
        <span>Profil Saya</span>
      </a>
    </nav>

    <div class="p-4 border-t border-dashed border-[var(--border)]">
      <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 transition-all">
          <i class="bi bi-box-arrow-left"></i>
          <span>Keluar Aplikasi</span>
        </button>
      </form>
    </div>
  </aside>

  <main class="flex-1 overflow-y-auto relative bg-[var(--bg)]">
    
    <div class="bg-gradient-to-br from-[#9E2A2B] to-[#561616] min-h-[300px] rounded-b-[40px] p-8 md:p-10 relative z-0">
        <div class="flex justify-between items-start">
            <div class="flex items-center gap-4">
                <button class="md:hidden text-white text-xl" onclick="openSidebar()">
                    <i class="bi bi-list"></i>
                </button>
                <div>
                    <h2 class="text-2xl md:text-3xl font-bold text-white m-0">Dashboard Overview</h2>
                    <p class="text-white/75 text-sm mt-2">Selamat datang kembali di portal layanan cuti.</p>
                </div>
            </div>

            <div class="relative group cursor-pointer">
                <div class="glass-profile px-4 py-2 rounded-full flex items-center gap-3 text-white transition-all">
                    <div class="w-9 h-9 rounded-full bg-white text-[var(--maroon)] flex items-center justify-center font-bold text-sm shadow-inner">
                        <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 2))); ?>

                    </div>
                    <div class="hidden md:block text-sm font-medium"><?php echo e($user->name ?? 'User'); ?></div>
                    <i class="bi bi-chevron-down text-[10px] hidden md:block opacity-70"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="px-5 md:px-8 -mt-32 pb-10 relative z-10 max-w-7xl mx-auto space-y-8">

      <section class="bg-white border-0 rounded-[2.5rem] p-8 md:p-10 shadow-soft flex flex-col justify-center min-h-[180px]">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div class="flex-1">
            <div class="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 rounded-full px-3 py-1 mb-4">
              <span class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              <span class="text-[10px] font-extrabold tracking-widest uppercase"><?php echo e($user->status ?? 'AKTIF'); ?></span>
            </div>
            <h3 class="text-2xl md:text-3xl font-extrabold text-slate-800 leading-tight">Halo, <?php echo e(explode(' ', $user->name ?? 'User')[0]); ?>! 👋</h3>
            <p class="text-slate-500 text-base font-medium mt-2 leading-relaxed md:w-3/4">Pantau sisa jatah cuti dan status pengajuan Anda.</p>
          </div>

          <div class="flex-shrink-0">
            <a href="<?php echo e(route('user.cuti.create')); ?>" class="btn-primary text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-red-900/20 text-sm md:text-base inline-flex items-center justify-center w-full md:w-auto transition-all hover:scale-[1.02] active:scale-[0.98]">
                <i class="bi bi-plus-circle-fill mr-3 text-lg"></i> Ajukan Cuti Baru
            </a>
          </div>
        </div>
      </section>

      <section class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        <div class="lg:col-span-5 space-y-4">
          <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm card-hover flex items-center gap-5">
            <div class="w-14 h-14 rounded-2xl bg-blue-50 flex items-center justify-center flex-shrink-0 border border-blue-100 text-blue-500">
              <i class="bi bi-files text-2xl"></i>
            </div>
            <div class="flex-1">
              <p class="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">Jatah Tahunan</p>
              <div class="flex items-baseline gap-2">
                <h3 class="text-3xl font-black text-slate-800 leading-none"><?php echo e($totalQuota ?? 12); ?></h3>
                <p class="text-[11px] text-slate-400 font-bold uppercase">Hari</p>
              </div>
              <div class="mt-3 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div class="bg-blue-500 h-full w-full"></div>
              </div>
            </div>
          </div>

          <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm card-hover flex items-center gap-5">
            <div class="w-14 h-14 rounded-2xl bg-orange-50 flex items-center justify-center flex-shrink-0 border border-orange-100 text-orange-500">
              <i class="bi bi-hourglass-split text-2xl"></i>
            </div>
            <div class="flex-1">
              <p class="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">Telah Diambil</p>
              <div class="flex items-baseline gap-2">
                <h3 class="text-3xl font-black text-orange-600 leading-none"><?php echo e($usedLeave ?? 0); ?></h3>
                <p class="text-[11px] text-slate-400 font-bold uppercase">Hari</p>
              </div>
              <div class="mt-3 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div class="bg-orange-500 h-full" style="width: <?php echo e((($usedLeave ?? 0)/($totalQuota ?? 12))*100); ?>%"></div>
              </div>
            </div>
          </div>

          <div class="bg-white rounded-3xl p-6 border border-emerald-100 shadow-sm card-hover flex items-center gap-5 bg-gradient-to-r from-white to-emerald-50/30">
            <div class="w-14 h-14 rounded-2xl bg-emerald-50 flex items-center justify-center flex-shrink-0 border border-emerald-100 text-emerald-600">
              <i class="bi bi-check-lg text-2xl"></i>
            </div>
            <div class="flex-1">
              <p class="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">Sisa Cuti Tersedia</p>
              <div class="flex items-baseline gap-2">
                <h3 class="text-4xl font-black text-slate-800 leading-none"><?php echo e($remainingLeave ?? 0); ?></h3>
                <p class="text-[11px] text-slate-400 font-bold uppercase">Hari</p>
              </div>
            </div>
          </div>
        </div>

        <div class="lg:col-span-7">
          <div class="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden h-full">
            <div class="p-6 border-b border-slate-50 flex justify-between items-center">
              <h4 class="text-sm font-bold text-slate-800 flex items-center gap-2">
                <i class="bi bi-clock-history text-[var(--maroon)]"></i> Pengajuan Terbaru
              </h4>
              <a href="<?php echo e(route('user.riwayat')); ?>" class="text-[11px] font-bold text-[var(--maroon)] hover:underline uppercase tracking-tighter">
                Lihat Semua
              </a>
            </div>

            <div class="p-5 space-y-4">
              <?php $__empty_1 = true; $__currentLoopData = $recentLeaves ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="flex items-center gap-4 p-4 rounded-2xl border border-slate-50 hover:bg-slate-50 transition-all group">
                <?php
                  $statusColor = [
                    'approved' => 'emerald',
                    'pending' => 'orange',
                    'rejected' => 'red'
                  ][$leave->status] ?? 'slate';
                  
                  $statusIcon = [
                    'approved' => 'bi-check-circle-fill',
                    'pending' => 'bi-hourglass-split',
                    'rejected' => 'bi-x-circle-fill'
                  ][$leave->status] ?? 'bi-info-circle';
                ?>
                
                <div class="w-12 h-12 rounded-xl bg-<?php echo e($statusColor); ?>-50 border border-<?php echo e($statusColor); ?>-100 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <i class="bi <?php echo e($statusIcon); ?> text-<?php echo e($statusColor); ?>-500 text-lg"></i>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="flex justify-between items-start gap-3">
                    <h5 class="font-bold text-slate-800 text-sm truncate"><?php echo e($leave->jenis_cuti); ?></h5>
                    <span class="text-[10px] font-bold bg-<?php echo e($statusColor); ?>-50 text-<?php echo e($statusColor); ?>-600 px-2.5 py-1 rounded-lg capitalize border border-<?php echo e($statusColor); ?>-100"><?php echo e($leave->status); ?></span>
                  </div>
                  <p class="text-xs text-slate-500 font-medium mt-1">
                    <?php echo e($leave->start_date->format('d M Y')); ?> • <span class="text-slate-800"><?php echo e($leave->duration); ?> Hari</span>
                  </p>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="text-center py-12">
                <div class="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="bi bi-folder2-open text-slate-200 text-3xl"></i>
                </div>
                <p class="text-slate-400 text-sm font-medium">Belum ada riwayat pengajuan cuti.</p>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </section>

      <div class="text-center pt-8 pb-4">
        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">© 2026 Pemerintah Kabupaten Semarang • Disdikbudpora</p>
      </div>
    </div>
  </main>

  <script>
    function openSidebar() {
      document.getElementById('sidebar').classList.remove('-translate-x-full');
      document.getElementById('overlay').classList.remove('hidden');
    }
    function closeSidebar() {
      document.getElementById('sidebar').classList.add('-translate-x-full');
      document.getElementById('overlay').classList.add('hidden');
    }
  </script>
</body>
</html><?php /**PATH D:\SIIPUL\resources\views/user/UserDashboard.blade.php ENDPATH**/ ?>