<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title', 'User'); ?> - SIIPUL</title>

    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f2',
                            100: '#fee2e2',
                            600: '#9E2A2B',
                            700: '#781F1F',
                            800: '#561616',
                        },
                        success: { 50: '#f0fdf4', 100: '#dcfce7', 600: '#16a34a' },
                        warning: { 50: '#fffbeb', 100: '#fef3c7', 600: '#d97706' },
                        danger:  { 50: '#fef2f2', 100: '#fee2e2', 600: '#dc2626' },
                    },
                    boxShadow: {
                        soft: '0 10px 25px -10px rgba(15, 23, 42, 0.15)',
                    }
                }
            }
        }
    </script>

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        /* Dropdown tanpa JS: pakai <details> */
        .dropdown-menu { display: none; }
        details[open] .dropdown-menu { display: block; }
        summary::-webkit-details-marker { display: none; }

        /* Modal: JS lama toggle class 'open' pada elemen id='modal' */
        #modal { display: none; }
        #modal.open { display: flex; }

        /* Scrollbar halus */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #94A3B8; }
    </style>
</head>

<body class="bg-slate-100 min-h-screen">

    <?php ($layoutUser = $user ?? auth()->user()); ?>

    <div class="min-h-screen flex">

        
        <?php echo $__env->make('user.partials.sidebar', ['user' => $layoutUser], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="flex-1 min-w-0 flex flex-col">

            
            <?php echo $__env->make('user.partials.topbar', ['user' => $layoutUser], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <section class="bg-gradient-to-br from-primary-700 via-primary-700 to-primary-800 text-white">
                <div class="w-full px-6 lg:px-10 pt-10 pb-24">
                    <div class="max-w-7xl mx-auto">
                        <div class="flex items-start justify-between gap-6">
                            <div>
                                <h1 class="text-3xl md:text-4xl font-extrabold tracking-tight"><?php echo $__env->yieldContent('page_title', trim($__env->yieldContent('title'))); ?></h1>
                                <?php if (! empty(trim($__env->yieldContent('page_subtitle')))): ?>
                                    <p class="mt-2 text-white/75"><?php echo $__env->yieldContent('page_subtitle'); ?></p>
                                <?php else: ?>
                                    <p class="mt-2 text-white/75">Pantau aktivitas cuti Anda secara real-time.</p>
                                <?php endif; ?>
                            </div>

                            <?php ($backUrl = trim($__env->yieldContent('back_url'))); ?>
                            <?php if(!empty($backUrl)): ?>
                                <a href="<?php echo e($backUrl); ?>" class="hidden sm:inline-flex items-center gap-2 rounded-full bg-white/10 hover:bg-white/15 border border-white/15 px-4 py-2 text-sm font-semibold transition">
                                    <i class="fa-solid fa-arrow-left"></i>
                                    Kembali
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>

            
            <main class="flex-1 -mt-16 pb-12">
                <div class="w-full px-6 lg:px-10">
                    <div class="max-w-7xl mx-auto">
                        <div class="rounded-3xl bg-slate-100">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </main>

            
            <?php echo $__env->make('user.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->yieldPushContent('scripts'); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\SIIPUL\resources\views/layouts/user.blade.php ENDPATH**/ ?>