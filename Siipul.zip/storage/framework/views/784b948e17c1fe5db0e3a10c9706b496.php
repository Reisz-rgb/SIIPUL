<?php ($u = $user ?? auth()->user()); ?>

<aside class="hidden lg:flex w-72 shrink-0 flex-col bg-white border-r border-slate-200">
    <div class="px-6 pt-6 pb-5">
        <div class="flex items-center gap-3">
            <img src="<?php echo e(asset('logokabupatensemarang.png')); ?>" alt="Logo" class="h-10 w-10 rounded-xl bg-slate-50 p-1 object-contain" />
            <div class="leading-tight">
                <div class="text-base font-extrabold tracking-tight text-primary-700">SIIPUL</div>
                <div class="text-xs font-semibold text-slate-500">Kab. Semarang</div>
            </div>
        </div>
    </div>

    <nav class="px-4 pb-4">
        <div class="text-[11px] font-extrabold text-slate-400 tracking-wider uppercase px-3">Main Menu</div>

        <div class="mt-3 space-y-1">
            <a href="<?php echo e(route('user.dashboard')); ?>" class="<?php echo e(request()->routeIs('user.dashboard')
                ? 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold bg-primary-700 text-white shadow-soft'
                : 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50'); ?>">
                <i class="fa-solid fa-grid-2 w-5 <?php echo e(request()->routeIs('user.dashboard') ? 'text-white/90' : 'text-slate-400'); ?>"></i>
                Dashboard
            </a>

            <a href="<?php echo e(route('user.cuti.create')); ?>" class="<?php echo e(request()->routeIs('user.cuti.create')
                ? 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold bg-primary-700 text-white shadow-soft'
                : 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50'); ?>">
                <i class="fa-regular fa-calendar-plus w-5 <?php echo e(request()->routeIs('user.cuti.create') ? 'text-white/90' : 'text-slate-400'); ?>"></i>
                Pengajuan Cuti
            </a>

            <a href="<?php echo e(route('user.riwayat')); ?>" class="<?php echo e(request()->routeIs('user.riwayat')
                ? 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold bg-primary-700 text-white shadow-soft'
                : 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50'); ?>">
                <i class="fa-regular fa-file-lines w-5 <?php echo e(request()->routeIs('user.riwayat') ? 'text-white/90' : 'text-slate-400'); ?>"></i>
                Riwayat
            </a>
        </div>

        <div class="mt-6 text-[11px] font-extrabold text-slate-400 tracking-wider uppercase px-3">Akun</div>
        <div class="mt-3 space-y-1">
            <a href="<?php echo e(route('user.profil')); ?>" class="<?php echo e((request()->routeIs('user.profil') || request()->routeIs('user.profil.*'))
                ? 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold bg-primary-700 text-white shadow-soft'
                : 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50'); ?>">
                <i class="fa-regular fa-user w-5 <?php echo e((request()->routeIs('user.profil') || request()->routeIs('user.profil.*')) ? 'text-white/90' : 'text-slate-400'); ?>"></i>
                Profil
            </a>

            <a href="<?php echo e(route('user.password.change')); ?>" class="<?php echo e(request()->routeIs('user.password.change')
                ? 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-extrabold bg-primary-700 text-white shadow-soft'
                : 'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50'); ?>">
                <i class="fa-solid fa-key w-5 <?php echo e(request()->routeIs('user.password.change') ? 'text-white/90' : 'text-slate-400'); ?>"></i>
                Ubah Password
            </a>
        </div>
    </nav>

    <div class="mt-auto px-4 pb-6">
        <div class="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div class="flex items-center gap-3">
                <div class="h-10 w-10 rounded-full bg-primary-700 text-white flex items-center justify-center font-extrabold text-sm">
                    <?php echo e(strtoupper(substr($u->name ?? 'US', 0, 2))); ?>

                </div>
                <div class="min-w-0">
                    <div class="text-sm font-extrabold text-slate-900 truncate"><?php echo e($u->name ?? '-'); ?></div>
                    <div class="text-xs font-semibold text-slate-500 truncate"><?php echo e($u->jabatan ?? 'Pegawai'); ?></div>
                </div>
            </div>

            <form action="<?php echo e(route('logout')); ?>" method="POST" class="mt-4">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-danger-600 font-extrabold text-sm px-4 py-2.5 transition">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                    Keluar Aplikasi
                </button>
            </form>
        </div>
    </div>
</aside>
<?php /**PATH D:\SIIPUL\resources\views/user/partials/sidebar.blade.php ENDPATH**/ ?>